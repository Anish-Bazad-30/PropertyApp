export const environment = {
  production: true,
  // API_URL: 'http://localhost:8080',
   API_URL: 'http://157.20.190.17:8082'
};
